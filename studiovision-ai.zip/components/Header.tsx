
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="py-6 border-b border-white/5 bg-black/80 backdrop-blur-xl sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        <div className="flex items-center gap-4 group cursor-pointer">
          {/* Minimalist Professional Camera Logo */}
          <div className="relative w-12 h-12 flex items-center justify-center">
            {/* Background Glow */}
            <div className="absolute inset-0 bg-orange-600/20 blur-lg rounded-full group-hover:bg-orange-600/40 transition-all duration-500"></div>
            
            {/* Camera Container */}
            <div className="relative w-11 h-11 bg-gradient-to-br from-gray-900 to-black rounded-xl border border-white/10 flex items-center justify-center shadow-2xl group-hover:border-orange-500/50 transition-all duration-300">
              <svg 
                width="28" 
                height="28" 
                viewBox="0 0 24 24" 
                fill="none" 
                xmlns="http://www.w3.org/2000/svg"
                className="transform group-hover:scale-110 transition-transform duration-500"
              >
                {/* Camera Body */}
                <rect x="3" y="7" width="18" height="13" rx="3.5" stroke="white" strokeWidth="1.5" strokeLinejoin="round" />
                {/* Viewfinder Top */}
                <path d="M8.5 7L10.2 4.5C10.4 4.2 10.7 4 11 4H13C13.3 4 13.6 4.2 13.8 4.5L15.5 7" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                {/* Outer Lens */}
                <circle cx="12" cy="13.5" r="4" stroke="white" strokeWidth="1.5" />
                {/* Inner Lens / Glow */}
                <circle cx="12" cy="13.5" r="1.5" fill="url(#lens-gradient)" />
                {/* Flash/Sensor Detail */}
                <rect x="17.5" y="9.5" width="1.5" height="1.5" rx="0.75" fill="white" fillOpacity="0.4" />
                
                <defs>
                  <radialGradient id="lens-gradient" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(12 13.5) rotate(90) scale(2)">
                    <stop stopColor="#fb923c" />
                    <stop offset="1" stopColor="#ea580c" stopOpacity="0" />
                  </radialGradient>
                </defs>
              </svg>
            </div>
          </div>

          <div>
            <h1 className="text-xl font-black tracking-[0.05em] bg-clip-text text-transparent bg-gradient-to-r from-white via-white to-orange-400 uppercase">
              Studiovision <span className="text-white">Ai</span>
            </h1>
            <p className="text-[9px] text-gray-500 font-bold uppercase tracking-[0.25em] flex items-center gap-1.5">
              <span className="w-1 h-1 bg-orange-600 rounded-full animate-pulse"></span>
              Created by Honourable
            </p>
          </div>
        </div>
        
        <nav className="hidden md:flex items-center gap-8">
          <a href="#" className="text-[10px] font-bold uppercase tracking-widest text-gray-500 hover:text-orange-400 transition-colors">Documentation</a>
          <a href="#" className="text-[10px] font-bold uppercase tracking-widest text-gray-500 hover:text-orange-400 transition-colors">Showcase</a>
          <button className="px-5 py-2.5 bg-white/5 text-white text-[10px] font-black rounded-full border border-white/10 hover:bg-orange-600 hover:border-orange-500 transition-all shadow-xl uppercase tracking-widest">
            Try Pro
          </button>
        </nav>
      </div>
    </header>
  );
};

export default Header;

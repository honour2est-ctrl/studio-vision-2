
import React, { useState, useCallback } from 'react';
import Header from './components/Header';
import ImageUploader from './components/ImageUploader';
import LoadingOverlay from './components/LoadingOverlay';
import ComparisonSlider from './components/ComparisonSlider';
import { transformProductImage } from './services/geminiService';
import { ImageState, StudioStyle, STYLE_CATEGORIES, StyleCategory } from './types';

const App: React.FC = () => {
  const [imageState, setImageState] = useState<ImageState>({
    original: null,
    transformed: null,
    isLoading: false,
    error: null,
  });

  const [prompt, setPrompt] = useState('');
  const [selectedStyle, setSelectedStyle] = useState<StudioStyle>(StudioStyle.CLEAN);
  const [activeCategory, setActiveCategory] = useState<StyleCategory>('Core');
  const [showSafeZones, setShowSafeZones] = useState(false);

  const handleImageSelect = useCallback((base64: string) => {
    setImageState(prev => ({ ...prev, original: base64, transformed: null, error: null }));
  }, []);

  const handleTransform = async () => {
    if (!imageState.original) return;
    setImageState(prev => ({ ...prev, isLoading: true, error: null }));
    
    try {
      const result = await transformProductImage(imageState.original, prompt, selectedStyle);
      setImageState(prev => ({ ...prev, transformed: result, isLoading: false }));
    } catch (err: any) {
      setImageState(prev => ({ ...prev, isLoading: false, error: err.message || "Transformation failed." }));
    }
  };

  const handleDownload = () => {
    if (!imageState.transformed) return;
    const link = document.createElement('a');
    link.href = imageState.transformed;
    link.download = `studiovision-${selectedStyle.toLowerCase().replace(/\s/g, '-')}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#050505] text-white selection:bg-orange-500/30 font-inter">
      <Header />

      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 w-full relative">
        {/* Ambient background glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-96 bg-orange-600/5 blur-[120px] pointer-events-none rounded-full"></div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 relative z-10">
          
          {/* Left Column: Controls */}
          <div className="lg:col-span-5 space-y-8">
            <section>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-sm font-bold flex items-center gap-2 uppercase tracking-widest text-gray-400">
                  <span className="w-5 h-5 rounded-full bg-orange-600 text-white flex items-center justify-center text-[10px]">1</span>
                  Input Source
                </h2>
                {imageState.original && (
                  <button onClick={() => setImageState({ original: null, transformed: null, isLoading: false, error: null })} className="text-[10px] text-gray-500 hover:text-orange-400 transition-colors uppercase tracking-widest font-bold">Reset</button>
                )}
              </div>
              <ImageUploader onImageSelect={handleImageSelect} currentImage={imageState.original} />
            </section>

            <section className="space-y-6 bg-gray-900/30 backdrop-blur-md p-6 rounded-3xl border border-white/5 shadow-inner">
              <div>
                <h2 className="text-sm font-bold mb-4 flex items-center gap-2 uppercase tracking-widest text-gray-400">
                   <span className="w-5 h-5 rounded-full bg-orange-600 text-white flex items-center justify-center text-[10px]">2</span>
                   Studio Presets
                </h2>
                
                {/* Category Tabs */}
                <div className="flex gap-2 mb-4 p-1 bg-black/40 rounded-xl">
                  {Object.keys(STYLE_CATEGORIES).map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setActiveCategory(cat as StyleCategory)}
                      className={`flex-1 py-2 text-[10px] font-bold uppercase tracking-widest rounded-lg transition-all ${activeCategory === cat ? 'bg-orange-600 text-white shadow-lg' : 'text-gray-500 hover:text-gray-300'}`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>

                {/* Style Grid */}
                <div className="grid grid-cols-2 gap-2 max-h-64 overflow-y-auto pr-2 custom-scrollbar">
                  {STYLE_CATEGORIES[activeCategory].map((style) => (
                    <button
                      key={style}
                      onClick={() => setSelectedStyle(style)}
                      className={`px-3 py-3 rounded-xl text-[11px] font-bold border transition-all text-left ${
                        selectedStyle === style ? 'bg-orange-600/20 border-orange-500 text-orange-400' : 'bg-black/40 border-white/5 text-gray-500 hover:border-white/10'
                      }`}
                    >
                      {style}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                <h2 className="text-sm font-bold flex items-center gap-2 uppercase tracking-widest text-gray-400">
                  <span className="w-5 h-5 rounded-full bg-orange-600 text-white flex items-center justify-center text-[10px]">3</span>
                  Smart Refinement
                </h2>
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="e.g. Enhance facial expressions, add rim lighting, or specific text stroke colors..."
                  className="w-full bg-black/60 border border-white/10 rounded-2xl p-4 text-sm focus:outline-none focus:ring-1 focus:ring-orange-500/50 resize-none h-28 transition-all placeholder:text-gray-700 font-mono text-orange-200/80"
                />
              </div>

              <button
                disabled={!imageState.original || imageState.isLoading}
                onClick={handleTransform}
                className={`w-full py-4 rounded-2xl font-bold flex items-center justify-center gap-3 transition-all ${
                  !imageState.original || imageState.isLoading
                    ? 'bg-gray-800 text-gray-500'
                    : 'bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white shadow-xl shadow-orange-600/20 active:scale-95'
                }`}
              >
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                {imageState.isLoading ? 'Processing Lens...' : 'Generate Studio Shot'}
              </button>
            </section>
          </div>

          {/* Right Column: Result Preview */}
          <div className="lg:col-span-7">
            <div className="sticky top-28 space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-bold uppercase tracking-widest text-gray-400 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-red-600 animate-pulse"></span>
                  Live Viewfinder
                </h2>
                <div className="flex gap-2">
                  <button 
                    onClick={() => setShowSafeZones(!showSafeZones)}
                    className={`px-3 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-widest border transition-all ${showSafeZones ? 'bg-orange-600 border-orange-500 text-white' : 'bg-black/40 border-white/10 text-gray-500 hover:border-white/20'}`}
                  >
                    Overlay {showSafeZones ? 'On' : 'Off'}
                  </button>
                </div>
              </div>

              <div className="relative aspect-[4/3] bg-[#020202] rounded-[2.5rem] overflow-hidden border border-white/10 flex items-center justify-center group shadow-[0_0_50px_rgba(0,0,0,1)]">
                {/* STUDIO CAMERA HUD BACKGROUND */}
                <div className="absolute inset-0 pointer-events-none z-10 opacity-30">
                    {/* Corner Brackets */}
                    <div className="absolute top-10 left-10 w-8 h-8 border-t-2 border-l-2 border-white/20"></div>
                    <div className="absolute top-10 right-10 w-8 h-8 border-t-2 border-r-2 border-white/20"></div>
                    <div className="absolute bottom-10 left-10 w-8 h-8 border-b-2 border-l-2 border-white/20"></div>
                    <div className="absolute bottom-10 right-10 w-8 h-8 border-b-2 border-r-2 border-white/20"></div>
                    
                    {/* Focus Points */}
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex gap-4">
                        <div className="w-4 h-0.5 bg-white/10"></div>
                        <div className="w-0.5 h-4 bg-white/10 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"></div>
                        <div className="w-4 h-0.5 bg-white/10"></div>
                    </div>

                    {/* Technical Readouts */}
                    <div className="absolute top-12 left-1/2 -translate-x-1/2 font-mono text-[9px] text-white/20 tracking-[0.4em] uppercase">
                        REC 4K HDR 10-BIT
                    </div>
                    
                    <div className="absolute bottom-12 left-12 flex flex-col gap-1 font-mono text-[9px] text-white/20">
                        <div className="flex items-center gap-2">
                            <span className="text-orange-500/40">ISO</span> 400
                        </div>
                        <div className="flex items-center gap-2">
                            <span className="text-orange-500/40">A</span> f/2.8
                        </div>
                        <div className="flex items-center gap-2">
                            <span className="text-orange-500/40">S</span> 1/250
                        </div>
                    </div>

                    <div className="absolute bottom-12 right-12 text-right font-mono text-[9px] text-white/20">
                        <div>24.00 FPS</div>
                        <div className="text-orange-500/40 mt-1 uppercase">RAW TRANSCODE</div>
                    </div>
                </div>

                {imageState.isLoading && <LoadingOverlay />}
                
                {imageState.transformed && imageState.original ? (
                  <div className="relative w-full h-full animate-fade-in">
                    <ComparisonSlider before={imageState.original} after={imageState.transformed} />
                    
                    {/* Safe Zone Overlay */}
                    {showSafeZones && (
                      <div className="absolute inset-0 pointer-events-none z-40">
                        <div className="absolute inset-y-0 left-1/2 -translate-x-1/2 w-[40%] border-x border-dashed border-cyan-500/30 flex items-start justify-center pt-4">
                          <span className="text-[7px] font-bold text-cyan-400 bg-black/60 px-1 rounded uppercase tracking-widest">Portrait Safe</span>
                        </div>
                        <div className="absolute bottom-0 left-0 right-0 h-1/5 bg-red-500/5 border-t border-dashed border-red-500/20 flex items-center justify-center">
                          <span className="text-[7px] font-bold text-red-400 bg-black/60 px-1 rounded uppercase tracking-widest">UI Buffer Zone</span>
                        </div>
                      </div>
                    )}

                    <div className="absolute bottom-6 right-6 flex gap-2 z-50">
                      <button onClick={handleDownload} className="px-6 py-2 bg-white/10 hover:bg-orange-600 text-white text-[10px] font-bold rounded-full border border-white/10 backdrop-blur-xl transition-all flex items-center gap-2 uppercase tracking-widest shadow-2xl">
                        Export Full Resolution
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="relative z-10 text-center p-12 group/inner">
                    <div className="w-20 h-20 bg-gray-900 border border-white/5 rounded-full flex items-center justify-center mx-auto mb-6 group-hover/inner:border-orange-500/40 transition-all duration-500">
                      <svg className="w-10 h-10 text-gray-700 group-hover/inner:text-orange-500 group-hover/inner:scale-110 transition-all" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                      </svg>
                    </div>
                    <p className="text-gray-500 font-bold uppercase tracking-[0.3em] text-[10px] group-hover/inner:text-orange-400 transition-colors">Digital Negative Loading</p>
                    <p className="text-xs text-gray-700 mt-2 italic max-w-xs mx-auto">Click generate to render your masterpiece onto the studio canvas.</p>
                  </div>
                )}
              </div>
            </div>
          </div>

        </div>
      </main>

      <footer className="py-16 border-t border-white/5 bg-[#030303]">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="flex flex-col items-center gap-4">
            <div className="w-12 h-1 bg-gradient-to-r from-transparent via-orange-600 to-transparent mb-4"></div>
            <p className="text-gray-500 text-[10px] uppercase tracking-[0.4em] font-bold">Studiovision Ai Engine v2.5 Premium</p>
            <p className="text-gray-400 text-xs mt-2 font-medium tracking-wide">
              Crafted with Precision by <span className="text-orange-500 font-extrabold uppercase tracking-tighter shadow-orange-500/20">Honourable</span>
            </p>
            <div className="mt-8 flex gap-8 text-[10px] font-bold uppercase tracking-widest text-gray-700">
               <a href="#" className="hover:text-orange-500 transition-colors">License</a>
               <a href="#" className="hover:text-orange-500 transition-colors">API Status</a>
               <a href="#" className="hover:text-orange-500 transition-colors">Changelog</a>
            </div>
          </div>
        </div>
      </footer>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #1a1a1a; border-radius: 10px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #ea580c; }
        @keyframes fade-in {
            from { opacity: 0; filter: blur(10px); }
            to { opacity: 1; filter: blur(0); }
        }
        .animate-fade-in {
            animation: fade-in 0.8s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default App;

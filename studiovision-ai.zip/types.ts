
export interface ImageState {
  original: string | null;
  transformed: string | null;
  isLoading: boolean;
  error: string | null;
}

export interface TransformOptions {
  prompt: string;
  style: string;
}

export enum StudioStyle {
  // Core
  BOLD = 'Bold & High Contrast',
  CLEAN = 'Clean Studio Pro',
  CINEMATIC = 'Cinematic Documentary',
  MINIMALIST = 'Modern Minimalist',
  
  // Attention
  VIBRANT = 'Vibrant Pop / YouTube',
  CARTOON = 'Illustrated / Cartoon',
  PIXAR = '3D / Pixar-Style',
  NEON = 'Neon Cyberpunk',
  
  // Brand
  LUXURY = 'Luxury & Premium Gold',
  RETRO = 'Retro Vintage Film',
  STREET = 'Urban Street Grit',
  DOCUMENTARY = 'Realistic Documentary',
  
  // Utility
  TEXT_FIRST = 'Text-First Headline',
  FACE_FOCUS = 'Face-Focused Emotion',
  SPLIT = 'Before & After Split'
}

export type StyleCategory = 'Core' | 'Attention' | 'Brand' | 'Utility';

export const STYLE_CATEGORIES: Record<StyleCategory, StudioStyle[]> = {
  Core: [StudioStyle.BOLD, StudioStyle.CLEAN, StudioStyle.CINEMATIC, StudioStyle.MINIMALIST],
  Attention: [StudioStyle.VIBRANT, StudioStyle.CARTOON, StudioStyle.PIXAR, StudioStyle.NEON],
  Brand: [StudioStyle.LUXURY, StudioStyle.RETRO, StudioStyle.STREET, StudioStyle.DOCUMENTARY],
  Utility: [StudioStyle.TEXT_FIRST, StudioStyle.FACE_FOCUS, StudioStyle.SPLIT]
};

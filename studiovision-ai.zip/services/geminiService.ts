
import { GoogleGenAI } from "@google/genai";
import { StudioStyle } from "../types";

export async function transformProductImage(
  base64Image: string,
  userPrompt: string,
  style: StudioStyle
): Promise<string> {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key not found in environment.");
  }

  const ai = new GoogleGenAI({ apiKey });
  
  // Technical high-fidelity style specifications
  const styleDirectives: Record<string, string> = {
    [StudioStyle.BOLD]: "Style: High-Impact Bold. Lighting: Hard directional with high-ratio contrast. Shadows: Deep, crushed blacks. Highlights: Blown out intentionally for pop. Colors: Hyper-saturated, strong separation.",
    [StudioStyle.CLEAN]: "Style: E-commerce Studio Pro. Lighting: 3-point softbox setup, uniform luminance. Background: Pure neutral gray/white #F5F5F5. Texture: Macro-detail clarity, clean edges, zero noise.",
    [StudioStyle.CINEMATIC]: "Style: Cinematic Documentary. Lighting: Soft directional, 45-degree key light, low-intensity fill, subtle rim-light separation. Grading: Teal-and-orange palette, warm highlights, deep but clean blacks. Depth: Shallow f/1.8 depth of field, soft background bokeh.",
    [StudioStyle.MINIMALIST]: "Style: Modern Minimalist. Lighting: Ambient diffused, soft shadows. Composition: Heavy negative space, center-weighted. Palette: Monochromatic or muted pastels. Zero clutter.",
    [StudioStyle.VIBRANT]: "Style: YouTube Vibrant Pop. Lighting: Internal glow, rim lighting. Effects: Glowing edges, thick outlines, color gradients. Intensity: Maximum saturation, high-energy contrast.",
    [StudioStyle.CARTOON]: "Style: Stylized Illustration. Technique: Cel-shading, bold black ink outlines, flat vibrant colors. Proportions: Slightly exaggerated. Zero photorealistic textures.",
    [StudioStyle.PIXAR]: "Style: 3D Animation. Surface: Subsurface scattering on skin/plastic, soft velvety textures. Lighting: Whimsical warm lighting, bright expressive eyes. Rendering: Octane-style 3D look.",
    [StudioStyle.NEON]: "Style: Cyberpunk Neon. Environment: Midnight city. Lighting: Hot pink and electric blue neon tubes. Reflections: Wet pavement/metallic surfaces. Glow: Bloom and lens flares.",
    [StudioStyle.LUXURY]: "Style: Premium Luxury. Accents: Metallic gold and polished marble. Lighting: Specular highlights on edges. Palette: Champagne, black, and gold. Vibe: High-end magazine editorial.",
    [StudioStyle.RETRO]: "Style: Vintage Film. Artifacts: 35mm film grain, light leaks, chromatic aberration. Colors: Faded, warm tint, lifted shadows. Vibe: 1970s nostalgic film stock.",
    [StudioStyle.STREET]: "Style: Urban Grit. Textures: Raw concrete, graffiti, worn brick. Lighting: Harsh street lamp lighting, dramatic long shadows. Contrast: High, gritty texture overlay.",
    [StudioStyle.DOCUMENTARY]: "Style: Realistic Photojournalism. Lighting: Available natural light. Grading: Neutral, authentic colors. Sharpness: Natural, no over-sharpening. Authentic documentary aesthetic.",
    [StudioStyle.TEXT_FIRST]: "Style: Typographic Layout. Background: Simplified, low-contrast to allow text readability. Lighting: Flat. Composition: Strategic empty zones for headlines.",
    [StudioStyle.FACE_FOCUS]: "Style: Emotion Booster. Subject: Enhanced micro-expressions. Skin: Professional frequency separation retouching. Eyes: Added catch-lights. Background: High-blur bokeh.",
    [StudioStyle.SPLIT]: "Style: Transformation Split. Visuals: Clearly defined vertical or horizontal contrast line showing a 'before and after' vibe in the final render.",
  };

  const fullPrompt = `
    TASK: Professional Visual Transformation. Transform the provided image into a high-quality studio shot.
    STYLE_SPEC: ${styleDirectives[style] || ""}
    USER_ADDITIONAL_INSTRUCTIONS: ${userPrompt}
    
    UNIVERSAL STUDIO RULES:
    1. SUBJECT INTEGRITY: Preserve the exact proportions and identity of the product or person. Do not distort.
    2. BACKGROUND: Replace the current background with the requested style environment.
    3. SHADOWS: Generate realistic contact shadows that match the new light direction.
    4. QUALITY: 4K Resolution, photorealistic rendering (unless Cartoon/3D requested), professional color balance.
    5. MOBILE-FIRST: High visual weight so the image is readable on small mobile screens.
  `;

  const base64Data = base64Image.split(',')[1] || base64Image;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            inlineData: {
              data: base64Data,
              mimeType: 'image/png',
            },
          },
          {
            text: fullPrompt,
          },
        ],
      },
    });

    const candidate = response.candidates?.[0];
    if (!candidate) throw new Error("No response from AI.");

    for (const part of candidate.content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }

    throw new Error("The AI returned a text response instead of an image. Try a simpler prompt or a different style.");
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    throw new Error(error.message || "Transformation failed. Please check your API key and connection.");
  }
}


import React, { useState, useEffect } from 'react';

const LoadingOverlay: React.FC = () => {
  const [messageIndex, setMessageIndex] = useState(0);
  const messages = [
    "Analyzing product edges...",
    "Calibrating studio lighting...",
    "Generating professional textures...",
    "Removing background imperfections...",
    "Perfecting soft shadows...",
    "Adding 4K details...",
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setMessageIndex((prev) => (prev + 1) % messages.length);
    }, 2500);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-black/90 backdrop-blur-2xl rounded-2xl p-6">
      <div className="relative w-24 h-24 mb-8">
        {/* Outer Ring */}
        <div className="absolute inset-0 rounded-full border-4 border-orange-600/10"></div>
        {/* Spinning Ring */}
        <div className="absolute inset-0 rounded-full border-4 border-t-orange-500 border-r-transparent border-b-transparent border-l-transparent animate-spin"></div>
        {/* Pulse Heart */}
        <div className="absolute inset-4 rounded-full bg-gradient-to-tr from-orange-600 to-amber-600 animate-pulse flex items-center justify-center shadow-lg shadow-orange-600/30">
          <svg className="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.642.321a2 2 0 01-1.583 0l-.642-.321a6 6 0 00-3.86-.517l-2.387.477a2 2 0 00-1.022.547l-.34.34a2 2 0 000 2.828l1.245 1.245A9 9 0 0021 13V4a2 2 0 00-2-2h-5a2 2 0 00-2 2v5a2 2 0 002 2h5a2 2 0 002-2V4z" />
          </svg>
        </div>
      </div>
      
      <div className="text-center">
        <h3 className="text-xl font-bold text-white mb-2 tracking-tight">StudioVision AI Processing</h3>
        <p className="text-orange-500 font-bold text-sm uppercase tracking-widest animate-pulse h-6">
          {messages[messageIndex]}
        </p>
      </div>
      
      <div className="mt-12 w-full max-w-xs h-1.5 bg-gray-900 rounded-full overflow-hidden border border-white/5">
        <div className="h-full bg-gradient-to-r from-orange-600 to-amber-500 w-1/3 animate-[progress_10s_ease-in-out_infinite] shadow-[0_0_10px_rgba(234,88,12,0.5)]"></div>
      </div>

      <style>{`
        @keyframes progress {
          0% { width: 0%; transform: translateX(-100%); }
          50% { width: 70%; transform: translateX(0%); }
          100% { width: 100%; transform: translateX(100%); }
        }
      `}</style>
    </div>
  );
};

export default LoadingOverlay;

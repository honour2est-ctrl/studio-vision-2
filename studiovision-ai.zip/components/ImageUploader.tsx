
import React, { useRef } from 'react';

interface ImageUploaderProps {
  onImageSelect: (base64: string) => void;
  currentImage: string | null;
}

const ImageUploader: React.FC<ImageUploaderProps> = ({ onImageSelect, currentImage }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        onImageSelect(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="w-full">
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        className="hidden"
      />
      
      {!currentImage ? (
        <div 
          onClick={handleClick}
          className="border-2 border-dashed border-gray-800 rounded-3xl aspect-square flex flex-col items-center justify-center p-8 cursor-pointer hover:border-orange-500/40 hover:bg-orange-500/[0.02] transition-all group relative overflow-hidden bg-[#080808]"
        >
          {/* Background Decorative Layer: Studio Stage */}
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            {/* Spotlight Effect */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-[radial-gradient(circle_at_center,rgba(234,88,12,0.08)_0%,transparent_70%)] group-hover:bg-[radial-gradient(circle_at_center,rgba(234,88,12,0.15)_0%,transparent_70%)] transition-all duration-700"></div>
            
            {/* Technical Grid Pattern */}
            <div className="absolute inset-0 opacity-[0.03] group-hover:opacity-[0.05] transition-opacity duration-500" 
                 style={{ backgroundImage: `radial-gradient(#ea580c 0.5px, transparent 0.5px), radial-gradient(#ea580c 0.5px, #080808 0.5px)`, backgroundSize: '24px 24px', backgroundPosition: '0 0, 12px 12px' }}>
            </div>

            {/* Viewfinder Corners */}
            <div className="absolute top-8 left-8 w-6 h-6 border-t-2 border-l-2 border-orange-500/20 group-hover:border-orange-500/40 transition-colors"></div>
            <div className="absolute top-8 right-8 w-6 h-6 border-t-2 border-r-2 border-orange-500/20 group-hover:border-orange-500/40 transition-colors"></div>
            <div className="absolute bottom-8 left-8 w-6 h-6 border-b-2 border-l-2 border-orange-500/20 group-hover:border-orange-500/40 transition-colors"></div>
            <div className="absolute bottom-8 right-8 w-6 h-6 border-b-2 border-r-2 border-orange-500/20 group-hover:border-orange-500/40 transition-colors"></div>

            {/* Floating Technical Lines */}
            <div className="absolute left-0 right-0 top-1/2 h-[1px] bg-gradient-to-r from-transparent via-orange-500/5 to-transparent"></div>
            <div className="absolute top-0 bottom-0 left-1/2 w-[1px] bg-gradient-to-b from-transparent via-orange-500/5 to-transparent"></div>
          </div>

          {/* Foreground Content */}
          <div className="relative z-10 flex flex-col items-center">
            <div className="w-20 h-20 rounded-2xl bg-black border border-white/5 flex items-center justify-center mb-6 group-hover:scale-110 group-hover:bg-orange-600/10 group-hover:border-orange-500/30 transition-all duration-500 shadow-2xl">
              <div className="relative">
                <svg className="w-10 h-10 text-gray-700 group-hover:text-orange-500 transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
                {/* Plus Badge */}
                <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-orange-600 rounded-full border-2 border-[#080808] flex items-center justify-center group-hover:scale-110 transition-transform">
                  <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 4v16m8-8H4" />
                  </svg>
                </div>
              </div>
            </div>
            <h3 className="text-xl font-bold text-white tracking-tight group-hover:text-orange-400 transition-colors">Drop Product Here</h3>
            <p className="text-sm text-gray-500 text-center mt-3 max-w-[240px] leading-relaxed">
              Enhance any photo to <span className="text-gray-300">Studio Pro</span> quality with perfect lighting.
            </p>
            
            <div className="mt-8 flex items-center gap-3">
              <div className="h-[1px] w-8 bg-white/5"></div>
              <div className="px-4 py-2 bg-black border border-white/5 rounded-full text-[10px] text-orange-500 font-bold uppercase tracking-[0.2em] group-hover:border-orange-500/30 group-hover:shadow-[0_0_15px_rgba(234,88,12,0.1)] transition-all">
                Select Files
              </div>
              <div className="h-[1px] w-8 bg-white/5"></div>
            </div>
          </div>

          {/* Background Glow Animation */}
          <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-orange-600/10 blur-[60px] rounded-full group-hover:bg-orange-600/20 transition-all"></div>
        </div>
      ) : (
        <div className="relative group rounded-3xl overflow-hidden border border-white/10 aspect-square shadow-2xl bg-[#0a0a0a]">
          <img 
            src={currentImage} 
            alt="Original product" 
            className="w-full h-full object-contain transition-transform duration-1000 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-black/70 opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center transition-all duration-300 backdrop-blur-sm">
            <button 
              onClick={handleClick}
              className="px-6 py-2 bg-orange-600 text-white text-xs font-bold rounded-full transform -translate-y-4 group-hover:translate-y-0 transition-all duration-300 uppercase tracking-widest shadow-xl shadow-orange-600/20 hover:bg-orange-500 active:scale-95"
            >
              Change Product
            </button>
            <p className="mt-4 text-[10px] text-orange-400/80 uppercase tracking-widest font-bold">Swap current draft</p>
          </div>
          <div className="absolute top-4 left-4 flex items-center gap-2 px-3 py-1 bg-black/60 backdrop-blur-md rounded-full text-[10px] font-bold text-orange-500 uppercase tracking-widest border border-orange-500/20">
            <div className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse"></div>
            Draft Image
          </div>
        </div>
      )}
    </div>
  );
};

export default ImageUploader;
